<?php 
include ('include/header.php');
$metakey=$db->prepare("SELECT * from meta where meta_id=7");
$metakey->execute(array(0));
$metakeyprint=$metakey->fetch(PDO::FETCH_ASSOC);
?>
<title><?php echo $metakeyprint['meta_title'] ?></title>
<meta name="description" content="<?php echo $metakeyprint['meta_descr'] ?>">
<meta name="keywords" content="<?php echo $metakeyprint['meta_keyword'] ?>">
<?php
include ('include/menu.php');
?>
<div class="main-content">
  <section class="inner-header parallax layer-overlay overlay-dark-7" data-bg-img="trex/<?php echo $settingsprint['ayar_resimyorumg']; ?>">
    <div class="container pt-70 pb-70">
      <div class="section-content">
        <div class="row"> 
          <div class="col-sm-8 xs-text-center">
            <h2 class="text-white mt-10">Video Galerimiz</h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container">
      <div class="section-content">
        <div class="row">
          <div class="col-md-12">
            <div id="grid" class="gallery-isotope grid-3 gutter clearfix">

              <?php 
              $vidsor=$db->prepare("SELECT * from videogaleri order by video_id DESC");
              $vidsor->execute(array(0)); 
              while ($vidprint=$vidsor->fetch(PDO::FETCH_ASSOC)) { ?>
                <div class="gallery-item photography">
                  <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $vidprint['video_link']; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                </div>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php include ('include/footer.php'); ?>
