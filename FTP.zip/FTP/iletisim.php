<?php 
include ('include/header.php');
$metakey=$db->prepare("SELECT * from meta where meta_id=8");
$metakey->execute(array(0));
$metakeyprint=$metakey->fetch(PDO::FETCH_ASSOC);
?>
<title><?php echo $metakeyprint['meta_title'] ?></title>
<meta name="description" content="<?php echo $metakeyprint['meta_descr'] ?>">
<meta name="keywords" content="<?php echo $metakeyprint['meta_keyword'] ?>">
<?php
include ('include/menu.php');
?>
<div class="main-content">
  <?php echo $settingsprint['ayar_harita']; ?>
  <section class="divider">
    <div class="container pt-60 pb-60">
      <div class="section-content">
        <div class="row">
          <div class="col-sm-12 col-md-3">
            <div class="contact-info text-center">
              <i class="fa fa-phone font-36 mb-10 text-theme-colored"></i>
              <h4>Telefon</h4>
              <h6 class="text-gray"><a href="tel:<?php echo $settingsprint['ayar_tel']; ?>" title="<?php echo $settingsprint['ayar_tel']; ?>"><?php echo $settingsprint['ayar_tel']; ?></a></h6>
            </div>
          </div>
           <div class="col-sm-12 col-md-3">
            <div class="contact-info text-center">
              <i class="fa fa-phone font-36 mb-10 text-theme-colored"></i>
              <h4>Fax</h4>
              <h6 class="text-gray"><?php echo $settingsprint['ayar_fax']; ?></h6>
            </div>
          </div>
          <div class="col-sm-12 col-md-3">
            <div class="contact-info text-center">
              <i class="fa fa-envelope font-36 mb-10 text-theme-colored"></i>
              <h4>E-Posta</h4>
              <h6 class="text-gray"><a href="mailto:<?php echo $settingsprint['ayar_mail']; ?>" ><?php echo $settingsprint['ayar_mail']; ?></a></h6>
            </div>
          </div>
          <div class="col-sm-12 col-md-3">
            <div class="contact-info text-center">
              <i class="fa fa-map-marker font-36 mb-10 text-theme-colored"></i>
              <h4>Adres</h4>
              <h6 class="text-gray"><?php echo $settingsprint['ayar_adres']; ?> <br /> <?php echo $settingsprint['ayar_il']." / ".$settingsprint['ayar_ilce']; ?></h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="divider bg-lighter">
    <div class="container">
      <div class="row pt-0">
        <div class="col-md-12">

          <form form action="trex/controller/function.php" method="post" id="mycontactform">
            <!-- Name -->
            <div class="col-md-6">
             <div class="form-group">

              <label for="form_name">Ad Soyad *</label>
              <input type="text" class="form-control" name="mesaj_ad" placeholder="Adınız Soyadınız" id="form_name">

            </div>
          </div><!-- /End Name -->
          <!-- Email Address -->
          <div class="col-md-6">
           <!-- Form Group -->
           <div class="form-group">

            <label for="form_email">Eposta Adresi *</label>
            <input type="email" class="form-control" name="mesaj_mail" placeholder="E-Posta Adresiniz" id="form_email">

          </div><!-- /End Form Group -->
        </div><!-- /End Email Address -->


        <!-- Email Address -->
        <div class="col-md-12">
         <!-- Form Group -->
         <div class="form-group">

          <label for="form_email">Telefon *</label>
          <input type="text" class="form-control" name="mesaj_tel" placeholder="Telefon Numaranız" id="form_email">

        </div><!-- /End Form Group -->
      </div><!-- /End Email Address -->

      <!-- Message -->
      <div class="col-md-12">
       <!-- Form Group -->
       <div class="form-group">

        <label for="form_message">Mesaj *</label>
        <textarea class="form-control" rows="5" name="mesaj_icerik" placeholder="Mesajınız"  id="form_message"></textarea>

      </div><!-- /End Form Group -->
    </div><!-- /End Message -->

    <!-- Submit Button -->
    <div class="col-md-12">
     <!-- Form Group -->
     <div class="form-group">

      <button name="iletisimform" type="submit" class="btn btn-dark btn-theme-colored btn-flat">Gönder</button>

    </div><!-- /End Form Group -->
  </div><!-- /End Submit Button -->


</form><!-- /End Form -->
</div>
</div>
</div>
</section>
</div>
<?php include ('include/footer.php'); ?>
