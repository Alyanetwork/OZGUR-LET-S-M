<?php 
include ('include/header.php');
$sayfasor=$db->prepare("SELECT * from sayfalar where sayfa_id=:sayfa_id order by sayfa_id ASC limit 25");
$sayfasor->execute(array(
  'sayfa_id' => $_GET['sayfa_id']
));
$sayfacek=$sayfasor->fetch(PDO::FETCH_ASSOC); ?>
<title><?php echo $sayfacek['sayfa_title'] ?></title>
<meta name="description" content="<?php echo $sayfacek['sayfa_descr'] ?>">
<meta name="keywords" content="<?php echo $sayfacek['sayfa_keyword'] ?>">
<?php
include ('include/menu.php');
?>
<div class="main-content">
  <section class="inner-header parallax layer-overlay overlay-dark-7" data-bg-img="trex/<?php echo $settingsprint['ayar_resimyorum']; ?>">
    <div class="container pt-70 pb-70">
      <div class="section-content">
        <div class="row"> 
          <div class="col-sm-8 xs-text-center">
            <h2 class="text-white mt-10"><?php echo $sayfacek['sayfa_baslik']; ?></h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h5><?php echo $sayfacek['sayfa_baslik']; ?></h5>
          <?php echo $sayfacek['sayfa_icerik']; ?>
        </div>
      </div>
    </div>
  </section>
</div>
<?php include ('include/footer.php'); ?>
