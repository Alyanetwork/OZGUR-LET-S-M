 <div class="col-sm-12 col-md-4">
  <div class="sidebar sidebar-left mt-sm-30 ml-30 ml-sm-0">
    <div class="widget">
      <h4 class="widget-title line-bottom">Hizmetler</h4>
      <div class="brochured">
        <ul class="list mt-0">
         <?php 
         $hizmetsors=$db->prepare("SELECT * from hizmetler order by hizmet_id DESC Limit 5");
         $hizmetsors->execute(array(0));
         while ($hizmetceks=$hizmetsors->fetch(PDO::FETCH_ASSOC)) {
          ?>
          <li><a href="<?=seo('hizmet-'.$hizmetceks["hizmet_baslik"]).'-'.$hizmetceks["hizmet_id"]?>"><?php echo mb_substr($hizmetceks['hizmet_baslik'], 0 , 15 , "UTF-8"); ?></a></li>
        <?php } ?>
        <li><a href="hizmetler">Tüm Hizmetler</a></li>
      </ul>
    </div>
  </div>
  <div class="widget">
    <h4 class="widget-title line-bottom">Hizmet Bölgeleri</h4>
    <div class="brochured">
      <ul class="list mt-0">
        <?php 
        $projesors=$db->prepare("SELECT * from projeler order by proje_id ASC Limit 5");
        $projesors->execute(array(0));
        while ($projeceks=$projesors->fetch(PDO::FETCH_ASSOC)) {
          ?>
          <li><a href="<?=seo('bolge-'.$projeceks["proje_baslik"]).'-'.$projeceks["proje_id"]?>"><?php echo mb_substr($projeceks['proje_baslik'], 0 , 55 , "UTF-8"); ?></a></li>
        <?php } ?>
        <li><a href="bolgeler">Tüm Bölgeler</a></li>
      </ul>
    </div>
  </div>
  <div class="widget">
    <h4 class="widget-title line-bottom">Blog</h4>
    <div class="brochured">
      <ul class="list mt-0">
       <?php 
       $blogsors=$db->prepare("SELECT * from blog order by blog_id DESC Limit 5");
       $blogsors->execute(array(0));
       while ($blogceks=$blogsors->fetch(PDO::FETCH_ASSOC)) {
        ?>
        <li><a href="<?=seo('blog-'.$blogceks["blog_baslik"]).'-'.$blogceks["blog_id"]?>"><?php echo mb_substr($blogceks['blog_baslik'], 0,40,"UTF-8"); ?></a></li>
      <?php } ?>

      <li><a href="blog">Tüm Konular</a></li>
    </ul>
  </div>
</div>

</div>
</div>
