
</head>
<body class="">
  <div id="wrapper" class="clearfix">
    <div id="preloader">
      <div id="spinner">
        <img class="ml-5" src="images/preloaders/9.gif">
      </div>
    </div>
    <header id="header" class="header">
      <div class="header-top bg-black-333 sm-text-center border-top-theme-color-3px p-0">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="widget no-border m-0">
                <ul class="list-inline xs-text-center text-white mt-5">
                  <li class="m-0 pl-10 pr-10"><a href="tel:<?php echo $settingsprint['ayar_tel']; ?>" class="text-white"><i class="fa fa-phone text-theme-colored"></i> <?php echo $settingsprint['ayar_tel']; ?></a></li>
                  <li class="m-0 pl-10 pr-10"><a href="mailto:<?php echo $settingsprint['ayar_mail']; ?>" class="text-white"><i class="fa fa-envelope-o text-theme-colored"></i> <?php echo $settingsprint['ayar_mail']; ?></a></li>
                </ul>
              </div>
            </div>
            <div class="col-md-4 pr-0">
              <div class="widget no-border m-0">
                <ul class="styled-icons icon-dark icon-flat icon-sm pull-right flip sm-pull-none sm-text-center mt-sm-15 hidden-xs">
                  <?php while($socialprint=$social->fetch(PDO::FETCH_ASSOC)) { ?>
                   <li>
                    <a href="<?php echo $socialprint['sosyal_link']; ?>">
                      <i class="fa <?php echo $socialprint['sosyal_icon']; ?> text-white"></i>
                    </a>
                  </li>
                <?php } ?>
              </ul>
            </div>
          </div>
          <div class="col-md-2 ">
            <a class="btn btn-colored btn-flat btn-theme-colored pb-10" href="randevu-al">Online  Randevu Al</a>
          </div>
        </div>
      </div>
    </div>
    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default">
            <a class="menuzord-brand pull-left flip xs-pull-center mt-20" href="<?php echo $settingsprint['ayar_siteurl']; ?>">
              <img src="trex/<?php echo $settingsprint['ayar_logo']; ?>" alt="<?php echo $settingsprint['ayar_firmaadi']; ?>">
            </a>

            <ul class="menuzord-menu">

             <?php 
                                                    // ALT MENU DÜZENİ YAPILMIŞTIR!!!!!
             $menulist=$db->prepare("SELECT * from omenu where omenu_ust=0 order by omenu_sira ASC");
             $menulist->execute(); 

             foreach ($menulist as $row) {
              $ust=$row['omenu_id'];
              $ustdurum=$row['omenu_durum'];
              $menuliste=$db->prepare("SELECT * from omenu where omenu_ust=$ust order by omenu_sira ASC");
              $menuliste->execute(); 
              ?>
              <!--sarkan menu-->
              <li> <a href="<?php echo $row['omenu_link']; ?>"><?php echo $row['omenu_ad']; ?></a>

                <?php if ($ustdurum<=0) {

                } else {
                  ?> <ul class="dropdown"> <?php
                } ?>


                <?php foreach ($menuliste as $key) { ?>

                  <li><a href="<?php echo $key['omenu_link']; ?>"><?php echo $key['omenu_ad']; ?></a></li>

                <?php   } if ($ustdurum<=0) {

                } else {
                  ?> </ul> <?php
                } ?>

              </li>
            <?php } ?>



          </ul>
        </nav>
      </div>
    </div>
  </div>
</header>
