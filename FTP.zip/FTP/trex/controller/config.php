<?php

try {

	$db=new PDO("mysql:host=localhost;dbname=servis",'root','labirent' );
	$db->query("SET CHARACTER SET utf8");
	//echo "veritabanı bağlantısı başarılı";

}

catch (PDOExpception $e) {

	echo $e->getMessage();
}
