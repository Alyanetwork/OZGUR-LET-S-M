$(document).ready(function () {
    swal({
        title: "İŞLEM BAŞARILI",
        text: "Yapılan işlem başarılı bir şekilde tamamlanmıştır.",
        type: "success",
        cancelButtonClass: 'btn-secondary ',
        confirmButtonClass: 'btn-success',
        confirmButtonText: 'Tamam!'
    });
})(jQuery);
