$(document).ready(function () {

    swal({
        title: "HATA!",
        text: "İşlem yapılırken bir sorun oluştu.",
        type: "error",
        cancelButtonClass: 'btn-secondary',
        confirmButtonClass: 'btn-danger',
        confirmButtonText: 'Kapat!'
    });

});
