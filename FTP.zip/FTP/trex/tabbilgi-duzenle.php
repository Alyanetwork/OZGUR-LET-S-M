<?php 
include 'header.php';
include 'topbar.php';
include 'sidebar.php';
$slaytedit=$db->prepare("SELECT * from tabbilgi where tabbilgi_id=:tabbilgi_id");
$slaytedit->execute(array(
	'tabbilgi_id' => $_GET['tabbilgi_id']
));
$slaytwrite=$slaytedit->fetch(PDO::FETCH_ASSOC);

?>		
<!-- ============================================================== -->
<!-- 						Content Start	 						-->
<!-- ============================================================== -->
<section class="main-content container">
	<div class="page-header">
		<h2>Tab Bilgi İşlemleri</h2>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-heading card-default">
					<div class="pull-right mt-10">
						<a href="tab-bilgi.php" class="btn btn-warning btn-icon"><i class="fa fa-reply"></i>Geri Dön</a>
					</div>
					Tab Bilgi Düzenle
				</div>
				<div class="card-block">

					<form method="POST" action="controller/function.php" enctype="multipart/form-data" class="form-horizontal">
						
						<div class="form-group">
							<input type="hidden" name="tabbilgi_id" value="<?php echo $slaytwrite['tabbilgi_id']; ?>">
						</div>
						<div class="form-group">
							<input type="hidden" name="eski_yol" value="<?php echo $slaytwrite['tabbilgi_resim']; ?>">
						</div>						
						<div class="form-group">
							<label>Tab Bilgi Başlık</label>
							<input type="text" name="tabbilgi_baslik" value="<?php echo $slaytwrite['tabbilgi_baslik']; ?>" class="form-control">
						</div>

						<div class="form-group">
							<label>Tab Bilgi Açıklama</label>
							<textarea class="summernote" name="tabbilgi_aciklama"><?php echo $slaytwrite['tabbilgi_aciklama']; ?></textarea>
						</div>
						<div class="form-group">
							<label>Tab Bilgi Resim</label>
							<p><img style="max-height: 100px;max-width: 100px;" src="<?php echo $slaytwrite['tabbilgi_resim']; ?>"></p>
						</div>
						<div class="form-group">
							<div class="fileinput fileinput-new input-group col-md-3" data-provides="fileinput">
								<div class="form-control" data-trigger="fileinput"><span class="fileinput-filename"></span></div>
								<span class="input-group-addon btn btn-primary btn-file ">
									<span class="fileinput-new">Yeni Yükle</span>
									<span class="fileinput-exists">Değiştir</span>
									<input type="file"  name="tabbilgi_resim">
								</span>
								<a href="#" class="input-group-addon btn btn-danger  hover fileinput-exists" data-dismiss="fileinput">Sil</a>
							</div>
						</div>
						<div class="form-group">
							<label>Botun Adı</label>
							<input type="text" name="tabbilgi_butonad" value="<?php echo $slaytwrite['tabbilgi_butonad']; ?>" class="form-control">
						</div>
						<div class="form-group">
							<label>Botun Link</label>
							<input type="text" name="tabbilgi_butonlink" value="<?php echo $slaytwrite['tabbilgi_butonlink']; ?>" class="form-control">
						</div>
						<div class="form-group">
							<label>Tab Bilgi Sıra</label>
							<input type="text" name="tabbilgi_sira" value="<?php echo $slaytwrite['tabbilgi_sira']; ?>" class="form-control">
						</div>
						<button style="cursor: pointer;" type="submit" name="tabbilgiduzenle" class="btn btn-success btn-icon"><i class="fa fa-floppy-o "></i>Güncelle</button>
					</form>
				</div>
			</div>
		</div>
	</div>

	<?php include 'footer.php'; ?>
