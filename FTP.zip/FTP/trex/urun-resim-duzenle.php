<?php 
include 'header.php';
include 'topbar.php';
include 'sidebar.php';
$urunedit=$db->prepare("SELECT * from urunler where urun_id=:urun_id");
$urunedit->execute(array(
	'urun_id' => $_GET['urun_id']
));
$urunwrite=$urunedit->fetch(PDO::FETCH_ASSOC);

?>		
<!-- ============================================================== -->
<!-- 						Content Start	 						-->
<!-- ============================================================== -->
<section class="main-content container">
	<div class="page-header">
		<h2>Ürün İşlemleri</h2>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-heading card-default">
					<div class="pull-right mt-10">
						<a href="urunler.php" class="btn btn-warning btn-icon"><i class="fa fa-reply"></i>Geri Dön</a>
					</div>
					Ürün Düzenle
				</div>
				<div class="card-block">

					<form method="POST" action="controller/function.php" enctype="multipart/form-data" class="form-horizontal">
						<div class="form-group">
							<input type="hidden" name="resim_urun" value="<?php echo $urunwrite['urun_id']; ?>">
						</div>
						<div class="form-group">
							<label>Yüklü Resim</label><br />
							<?php 
							$resimsor=$db->prepare("SELECT * from resim where resim_urun=:resim_id");
							$resimsor->execute(array(
								'resim_id' => $urunwrite['urun_id']
							));
							$say=$resimsor->rowCount();
							$resimcek=$resimsor->fetch(PDO::FETCH_ASSOC); ?>
							<img style="padding: 10px;" style="max-height: 200px;" src="<?php echo $resimcek['resim_link']; ?>">
						</div>
						<div class="form-group">
							<input type="hidden" name="resim_id" value="<?php echo $resimcek['resim_link']; ?>">
						</div>
						<?php if ($say=='0') { ?>
						<div class="form-group">
							<div class="fileinput fileinput-new input-group col-md-3" data-provides="fileinput">
								<div class="form-control" data-trigger="fileinput"><span class="fileinput-filename"></span></div>
								<span class="input-group-addon btn btn-primary btn-file ">
									<span class="fileinput-new">Yeni Yükle</span>
									<span class="fileinput-exists">Değiştir</span>
									<input type="file" name="resim_link">
								</span>
								<a href="#" class="input-group-addon btn btn-danger  hover fileinput-exists" data-dismiss="fileinput">Sil</a>
							</div>
						</div>
						<button style="cursor: pointer;" type="submit" name="urunresimekle" class="btn btn-success btn-icon"><i class="fa fa-floppy-o "></i>Kaydet</button>
						<?php } else { ?>
						<a href="controller/function.php?urunresimsil=ok&resim_id=<?php echo $resimcek['resim_id']; ?>&eski_yol=<?php echo $resimcek['resim_link']; ?>&urun_id=<?php echo $urunwrite['urun_id']; ?>" class="btn btn-danger btn-icon"><i class="fa fa-times"></i>Resmi Sil</a>
						<?php } ?>
						
					</form>
				</div>
			</div>
		</div>
	</div>

	<?php include 'footer.php'; ?>