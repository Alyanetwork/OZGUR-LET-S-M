<?php 
include ('include/header.php');
$blogsor=$db->prepare("SELECT * from blog where blog_id=:blog_id");
$blogsor->execute(array(
  'blog_id' => $_GET['blog_id']
));
$blogcek=$blogsor->fetch(PDO::FETCH_ASSOC);
?>
<title><?php echo $blogcek['blog_title'] ?></title>
<meta name="description" content="<?php echo $blogcek['blog_descr'] ?>">
<meta name="keywords" content="<?php echo $blogcek['blog_keyword'] ?>">
</head>
<?php
include ('include/menu.php');
?>
<div class="main-content">
  <section class="inner-header parallax layer-overlay overlay-dark-7" data-bg-img="trex/<?php echo $settingsprint['ayar_resimcounter']; ?>">
    <div class="container pt-70 pb-70">
      <div class="section-content">
        <div class="row"> 
          <div class="col-sm-8 xs-text-center">
            <h2 class="text-white mt-10"><?php echo $blogcek['blog_baslik']; ?></h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container mt-30 mb-30 pt-30 pb-30">
      <div class="row">
        <div class="col-md-8 blog-pull-right">
          <div class="single-service">
            <h4 class="mt-0 mb-20"><?php echo $blogcek['blog_baslik']; ?></h4>
            <img style="width: 100%;" src="trex/<?php echo $blogcek['blog_resim']; ?>" class="img-responsive" alt="<?php echo $blogcek['blog_baslik']; ?>" />
            <p><?php echo $blogcek['blog_detay']; ?></p>
          </div>
        </div>
        <?php include ('include/sidebar.php'); ?>
      </div>
    </div>
  </section>
</div>
<?php include ('include/footer.php'); ?>
