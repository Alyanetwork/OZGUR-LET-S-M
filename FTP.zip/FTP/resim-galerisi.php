<?php 
include ('include/header.php');
$metakey=$db->prepare("SELECT * from meta where meta_id=6");
$metakey->execute(array(0));
$metakeyprint=$metakey->fetch(PDO::FETCH_ASSOC);
?>
<title><?php echo $metakeyprint['meta_title'] ?></title>
<meta name="description" content="<?php echo $metakeyprint['meta_descr'] ?>">
<meta name="keywords" content="<?php echo $metakeyprint['meta_keyword'] ?>">
<?php
include ('include/menu.php');
?>
<div class="main-content">
  <section class="inner-header parallax layer-overlay overlay-dark-7" data-bg-img="trex/<?php echo $settingsprint['ayar_resimyorumg']; ?>">
    <div class="container pt-70 pb-70">
      <div class="section-content">
        <div class="row"> 
          <div class="col-sm-8 xs-text-center">
            <h2 class="text-white mt-10">Foto Galerimiz</h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container">
      <div class="section-content">
        <div class="row">
          <div class="col-md-12">
            <div id="grid" class="gallery-isotope grid-4 gutter clearfix">
             <?php 
             $resimgaleri=$db->prepare("SELECT * from resimgaleri order by resim_id");
             $resimgaleri->execute();
             while($resimgalericek=$resimgaleri->fetch(PDO::FETCH_ASSOC)) { ?>


              <div class="gallery-item photography">
                <div class="thumb">
                  <a href="trex/<?php echo $resimgalericek['resim_link'] ?>" data-fancybox="gallery">
                    <img style="height: 200px;" src="trex/<?php echo $resimgalericek['resim_link'] ?>" alt="Resim Galerisi" />
                  </a>
                </div>
              </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</div>
<?php include ('include/footer.php'); ?>
