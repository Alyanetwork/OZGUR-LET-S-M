<?php 
include ('include/header.php');
?>
<title><?php echo $settingsprint['ayar_title'] ?></title>
<meta name="description" content="<?php echo $settingsprint['ayar_description'] ?>">
<meta name="keywords" content="<?php echo $settingsprint['ayar_keywords'] ?>">
<?php
include ('include/menu.php');
include ('include/slider.php');

if ($widgetprint['widget_bilgi']==1) { ?>


  <section>
    <div class="container pt-0 pb-0">
      <div class="section-content">
        <div class="row" data-margin-top="-70px">
          <?php 
          $bilgisor=$db->prepare("SELECT * from bilgi");
          $bilgisor->execute(array(0));
          while ($bilgicek=$bilgisor->fetch(PDO::FETCH_ASSOC)) {
           ?>
           <div class="col-sm-12 col-md-3">
            <div class="icon-box p-40 iconbox-theme-colored bg-white border-1px text-center">
              <img src="trex/<?php echo $bilgicek['bilgi_resim'] ?>">
              <h4 class="mt-0"><?php echo $bilgicek['bilgi_baslik'] ?></h4>
              <p><?php echo $bilgicek['bilgi_aciklama'] ?></p>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
</section>
<?php } if ($widgetprint['widget_counter']==1) { ?>
  <section class="">
    <div class="container">
      <div class="section-content">
        <div class="row">
          <div class="col-md-8 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
            <?php echo $widgetprint['widget_html2']; ?>
          </div>
          <div class="col-md-4 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s">
            <div class="row">
              <div class="col-md-10">
                <div class="img-hover-border mt-sm-40">
                  <img class="img-fullwidth" src="trex/<?php echo $settingsprint['ayar_resimparalax']; ?>">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php } if ($widgetprint['widget_welcome']==1) { ?>
  <section>
    <div class="container pt-50">
      <div class="row">
        <div class="col-md-12">
          <div class="call-to-action bg-theme-colored border-dashed-1px box-shadow-theme-colored-6px sm-text-center p-20">
            <div class="col-md-9">
              <h3 class="mt-10 mb-0 text-white"><?php echo $widgetprint['widget_bwelcome']; ?></h3>
            </div>
            <div class="col-md-3 text-right flip sm-text-center"> 
              <a class="btn btn-default text-uppercase font-weight-600 mt-0 mt-sm-15 pt-15 pb-15" href="randevu-al">RANDEVU AL<i class="fa fa-angle-double-right font-16 ml-10"></i></a> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php } if ($widgetprint['widget_hizmet']==1) { ?>
  <section>
    <div class="container pb-40">
      <div class="section-title vertical-line">
        <div class="row">
          <div class="col-md-12">
            <h2 class="text-theme-colored title"><?php echo $widgetprint['widget_bhizmet']; ?></h2>
          </div>
        </div>
      </div>
      <div class="row multi-row-clearfix">
        <div class="col-md-12">
          <div class="owl-carousel-3col owl-nav-top" data-nav="true">

            <?php 
            $hizmetsor=$db->prepare("SELECT * from hizmetler order by hizmet_id DESC");
            $hizmetsor->execute(array(0));
            while ($hizmetcek=$hizmetsor->fetch(PDO::FETCH_ASSOC)) {
              ?>
              <div class="item">
                <div class="project mb-30">
                  <div class="thumb">
                    <img style="height: 200px" class="img-fullwidth" alt="" src="trex/<?php echo $hizmetcek['hizmet_resim']; ?>">
                    <div class="hover-link">
                      <a href="<?=seo('hizmet-'.$hizmetcek["hizmet_baslik"]).'-'.$hizmetcek["hizmet_id"]?>"><i class="flaticon-attachment"></i></a>
                    </div>
                  </div>
                  <div class="project-details p-15 pt-10 pb-10">
                    <h4 class="title font-weight-700 mt-0"><a href="<?=seo('hizmet-'.$hizmetcek["hizmet_baslik"]).'-'.$hizmetcek["hizmet_id"]?>"><?php echo mb_substr($hizmetcek['hizmet_baslik'], 0 , 25 , "UTF-8"); ?></a></h4>
                  </div>
                </div>
              </div>
            <?php } ?>
          </div>
        </div>
      </div>
      <div class="section-title text-center">
        <div class="row">
          <div class="col-md-12">
            <a href="hizmetler" class="btn btn-dark btn-theme-colored mt-20 mb-sm-30">Tüm Hizmetler</a>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php } if ($widgetprint['widget_blog']==1) { 

  if ($widgetprint['widget_yorum']==0) { ?>
    <section>
      <div class="container">
        <div class="col-lg-12">
          <h3 class="line-bottom mt-0 mt-sm-40"><?php echo $widgetprint['widget_bblog']; ?></h3>
          <div class="owl-carousel-4col owl-nav-top" data-nav="false">
            <?php 
            $blogsor=$db->prepare("SELECT * from blog order by blog_id DESC Limit 5");
            $blogsor->execute(array(0));
            while ($blogcek=$blogsor->fetch(PDO::FETCH_ASSOC)) {
              $blogicerik=mb_substr(strip_tags($blogcek['blog_detay']), 0, 70, 'UTF-8')."...";
              ?>


              <div class="item">
                <article class="post clearfix bg-lighter mb-sm-30">
                  <div class="entry-header">
                    <div class="post-thumb thumb"> 
                      <img src="trex/<?php echo $blogcek['blog_resim']; ?>" alt="<?php echo $blogcek['blog_baslik']; ?>" class="img-responsive img-fullwidth">
                    </div>
                  </div>
                  <div class="entry-content p-20">
                    <h4 class="entry-title text-white" style="height: 50px;"><a class="font-weight-600" href="<?=seo('blog-'.$blogcek["blog_baslik"]).'-'.$blogcek["blog_id"]?>"><?php echo mb_substr($blogcek['blog_baslik'], 0,25,"UTF-8"); ?></a></h4>
                    <p class="mt-5"><?php echo mb_substr($blogcek['blog_detay'], 0,100,"UTF-8"); ?></p>
                    <a class="btn btn-theme-colored btn-sm mt-10" href="<?=seo('blog-'.$blogcek["blog_baslik"]).'-'.$blogcek["blog_id"]?>">Detaylar</a>
                  </div>
                </article>
              </div>
            <?php } ?>

          </div>
        </div>
      </div>
    </section>
  <?php } else { ?>
    <section>
      <div class="container">
        <div class="col-lg-7">
          <h3 class="line-bottom mt-0 mt-sm-40"><?php echo $widgetprint['widget_bblog']; ?></h3>
          <div class="owl-carousel-2col owl-nav-top" data-nav="false">
            <?php 
            $blogsor=$db->prepare("SELECT * from blog order by blog_id DESC Limit 5");
            $blogsor->execute(array(0));
            while ($blogcek=$blogsor->fetch(PDO::FETCH_ASSOC)) {
              $blogicerik=mb_substr(strip_tags($blogcek['blog_detay']), 0, 70, 'UTF-8')."...";
              ?>


              <div class="item">
                <article class="post clearfix bg-lighter mb-sm-30">
                  <div class="entry-header">
                    <div class="post-thumb thumb"> 
                      <img src="trex/<?php echo $blogcek['blog_resim']; ?>" alt="<?php echo $blogcek['blog_baslik']; ?>" class="img-responsive img-fullwidth">
                    </div>
                  </div>
                  <div class="entry-content p-20">
                    <h4 class="entry-title text-white" style="height: 50px;"><a class="font-weight-600" href="<?=seo('blog-'.$blogcek["blog_baslik"]).'-'.$blogcek["blog_id"]?>"><?php echo mb_substr($blogcek['blog_baslik'], 0,25,"UTF-8"); ?></a></h4>
                    <p class="mt-5"><?php echo mb_substr($blogcek['blog_detay'], 0,100,"UTF-8"); ?></p>
                    <a class="btn btn-theme-colored btn-sm mt-10" href="<?=seo('blog-'.$blogcek["blog_baslik"]).'-'.$blogcek["blog_id"]?>">Detaylar</a>
                  </div>
                </article>
              </div>
            <?php } ?>

          </div>
        </div>
        <div class="col-md-5">
          <h3 class="line-bottom mt-0 mt-sm-40"><?php echo $widgetprint['widget_byorum']; ?></h3>
          <div class="bxslider bx-nav-top">
            <?php 
            $yorumsor=$db->prepare("SELECT * from yorumlar order by yorum_id DESC");
            $yorumsor->execute(array(0));
            while ($yorumcek=$yorumsor->fetch(PDO::FETCH_ASSOC)) {
              ?>

              <div class="media border-1px bg-white sm-maxwidth400 p-15 mt-0 mb-15">
                <div class="testimonial pt-10">
                  <div>
                    <div class="col-md-2"><img src="trex/<?php echo $yorumcek['yorum_resim']; ?>" title="yorum"><?php echo $yorumcek['yorum_isim']; ?></div>
                    <div class="col-md-10"><p><?php echo $yorumcek['yorum_icerik']; ?></p></div>
                  </div>
                </div>
              </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </section>

  <?php } } if ($widgetprint['widget_blog']==0 && $widgetprint['widget_yorum']==1) { ?> 
    <!-- Section: Client Say -->
    <section class="bg-silver-light bg-no-repeat bg-img-left-top" data-bg-img="images/photos/2.png">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <h2 class="line-bottom-center mt-0"><?php echo $widgetprint['widget_byorum']; ?></h2>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <div class="owl-carousel-1col" data-dots="true">
               <?php 
               $yorumsor=$db->prepare("SELECT * from yorumlar order by yorum_id DESC");
               $yorumsor->execute(array(0));
               while ($yorumcek=$yorumsor->fetch(PDO::FETCH_ASSOC)) {
                ?>
                <div class="media border-1px bg-white sm-maxwidth400 p-15 mt-0 mb-15">
                  <div class="testimonial pt-10">
                    <div>  
                      <div class="col-md-2"><p class="author mb-10">
                        <img style="height: 100px;width: 100px" src="trex/<?php echo $yorumcek['yorum_resim']; ?>" title="yorum">
                        <?php echo $yorumcek['yorum_isim']; ?></p></div>
                        <div class="col-md-10"><p><?php echo $yorumcek['yorum_icerik']; ?></p></div>
                      </div>
                    </div>
                  </div>
                <?php } ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


  <?php } include ('include/footer.php'); ?>
